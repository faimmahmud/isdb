Royal Arc Tourism — PHP + Bootstrap

Pages:
- index.php
- destinations.php
- packages.php
- gallery.php
- contact.php
- user/dashboard.php
- admin/dashboard.php

Includes:
- includes/header.php
- includes/footer.php

Assets:
- assets/style.css
- assets/script.js

Open index.php with a PHP server:
- XAMPP / WAMP / Laragon
- or run: php -S localhost:8000
