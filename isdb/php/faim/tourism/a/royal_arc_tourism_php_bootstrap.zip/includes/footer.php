
  </main>
  <footer class="py-4 mt-5">
    <div class="container text-center text-white-50">
      <small>© 2026 Royal Arc Tourism — premium architectural tourism experience.</small>
    </div>
  </footer>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="assets/script.js"></script>
</body>
</html>
