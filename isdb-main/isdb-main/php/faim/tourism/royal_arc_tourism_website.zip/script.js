
const reveals = document.querySelectorAll('.reveal');
const io = new IntersectionObserver(entries => {
  for (const entry of entries) {
    if (entry.isIntersecting) entry.target.classList.add('visible');
  }
}, {threshold: 0.12});
reveals.forEach(el => io.observe(el));

document.querySelectorAll('.nav a').forEach(a => {
  if (a.getAttribute('href') === location.pathname.split('/').pop()) {
    a.classList.add('active');
  }
});
